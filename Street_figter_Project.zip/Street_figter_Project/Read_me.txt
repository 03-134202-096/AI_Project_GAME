1:  Open All files

2: install SK learn,Joblib,Numpy,Pandas libraries

3: run controller.py file through terminal like (python controller.py 1)

4: Open rom from BozHawk and run Game