from multiprocessing.dummy.connection import families
import socket
import json
from game_state import GameState
# from bot import fight
import sys
from bot import Bot
import pandas as pd
import os

data=[]
# Initialize lists to store column names and values




def connect(port):
    #For making a connection with the game
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("127.0.0.1", port))
    server_socket.listen(5)
    (client_socket, _) = server_socket.accept()
    print ("Connected to game!")
    return client_socket

def send(client_socket, command):
    #This function will send your updated command to Bizhawk so that game reacts according to your command.
    command_dict = command.object_to_dict()
    pay_load = json.dumps(command_dict).encode()
    client_socket.sendall(pay_load)

def receive(client_socket):
    #receive the game state and return game state
    pay_load = client_socket.recv(4096)
    input_dict = json.loads(pay_load.decode())
    game_state = GameState(input_dict)
    return game_state



def main():
    if (sys.argv[1]=='1'):
        client_socket = connect(9999)
    elif (sys.argv[1]=='2'):
        client_socket = connect(10000)
    current_game_state = None
    #print( current_game_state.is_round_over )
    col= [
    'timer', 'is_round_over', 'fightResult', 'has_round_started',
    'health', 'x_coord', 'y_coord', 'player1_id', 'player1_is_jumping', 'player1_is_crouching',
    'p1_is_player_in_move', 'p1_move_id', 'player1_buttons_up', 'player1_buttons_down',
    'player1_buttons_right', 'player1_buttons_left','p1_x','p1_y','p1_A','p1_B','p1_L','p1_R',
    'p2_health', 'p2_x_coord', 'p2_y_coord', 'player2_id', 'player2_is_jumping', 'player2_is_crouching',
    'player2_is_player_in_move', 'player2_move_id', 'player2_buttons_up', 'player2_buttons_down',
    'player2_buttons_right', 'player2_buttons_left'
    ]
    bot=Bot()
    inner=pd.DataFrame()
    temp=pd.DataFrame(columns=col)
    while (current_game_state is None) or (not current_game_state.is_round_over):

        current_game_state = receive(client_socket)
        bot_command = bot.fight(current_game_state,sys.argv[1], inner)
        send(client_socket, bot_command)

        timer = current_game_state.timer
        is_round_over = current_game_state.is_round_over
        fightResult = current_game_state.fight_result
        has_round_started = current_game_state.has_round_started


        row_data = [
            timer, is_round_over, fightResult, has_round_started,
            current_game_state.player1.health, current_game_state.player1.x_coord,
            current_game_state.player1.y_coord, current_game_state.player1.player_id,
            current_game_state.player1.is_jumping, current_game_state.player1.is_crouching,
            current_game_state.player1.is_player_in_move, current_game_state.player1.move_id,
            current_game_state.player1.player_buttons.up, current_game_state.player1.player_buttons.down,
            current_game_state.player1.player_buttons.right, current_game_state.player1.player_buttons.left,
            current_game_state.player1.player_buttons.X,current_game_state.player1.player_buttons.Y,current_game_state.player1.player_buttons.A,current_game_state.player1.player_buttons.B,current_game_state.player1.player_buttons.L,current_game_state.player1.player_buttons.R
            ,current_game_state.player2.health, current_game_state.player2.x_coord,
            current_game_state.player2.y_coord, current_game_state.player2.player_id,
            current_game_state.player2.is_jumping, current_game_state.player2.is_crouching,
            current_game_state.player2.is_player_in_move, current_game_state.player2.move_id,
            current_game_state.player2.player_buttons.up, current_game_state.player2.player_buttons.down,
            current_game_state.player2.player_buttons.right, current_game_state.player2.player_buttons.left
        ]



        data.append(row_data)

        df = pd.DataFrame(data, columns=col)


        #checks if the game is not over, enters the data frame
        if current_game_state is not None:

            row_dict = dict(zip(col, row_data))
            prev=temp
            temp= pd.DataFrame(row_dict,index=[0])
            #temp['is_round_over'] = temp['is_round_over'].apply(lambda x: x.map({'NOT_OVER': 0, 'P1': 1, 'P2': 2}))
            temp = temp.applymap(lambda x: 1 if x == 'P1' else (0 if x == 'NOT_OVER' else x))





        inner = temp[[ 'is_round_over','fightResult', 'has_round_started', 'player1_is_jumping', 'player1_is_crouching', 'p1_is_player_in_move', 'player2_is_jumping', 'player2_is_crouching', 'player2_is_player_in_move', 'player2_buttons_up', 'player2_buttons_down', 'player2_buttons_right', 'player2_buttons_left']]



if __name__ == '__main__':
   main()







####################  dataset    #################




#
# import socket
# import csv
# import pickle
# import json
# from game_state import GameState
# # from bot import fight
# import sys
# from bot import Bot
# import pandas as pd
#
#
# def connect(port):
#     # For making a connection with the game
#     server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#     server_socket.bind(("127.0.0.1", port))
#     server_socket.listen(5)
#     (client_socket, _) = server_socket.accept()
#     print("Connected to game!")
#     return client_socket
#
#
# def send(client_socket, command):
#     # This function will send your updated command to Bizhawk so that game reacts according to your command.
#     command_dict = command.object_to_dict()
#     pay_load = json.dumps(command_dict).encode()
#     client_socket.sendall(pay_load)
#
#
# def receive(client_socket):
#     # receive the game state and return game state
#     pay_load = client_socket.recv(4096)
#     input_dict = json.loads(pay_load.decode())
#     game_state = GameState(input_dict)
#     return game_state
#
#
# def record_to_csv(current_game_state, csv_file_path):
#     col = [
#         'timer', 'is_round_over', 'fightResult', 'has_round_started',
#         'health', 'x_coord', 'y_coord', 'player1_id', 'player1_is_jumping', 'player1_is_crouching',
#         'p1_is_player_in_move', 'p1_move_id', 'player1_buttons_up', 'player1_buttons_down',
#         'player1_buttons_right', 'player1_buttons_left', 'p1_x', 'p1_y', 'p1_A', 'p1_B', 'p1_L', 'p1_R',
#         'p2_health', 'p2_x_coord', 'p2_y_coord', 'player2_id', 'player2_is_jumping', 'player2_is_crouching',
#         'player2_is_player_in_move', 'player2_move_id', 'player2_buttons_up', 'player2_buttons_down',
#         'player2_buttons_right', 'player2_buttons_left']
#
#     row_data = [
#         current_game_state.timer, current_game_state.is_round_over, current_game_state.fight_result,
#         current_game_state.has_round_started,
#         current_game_state.player1.health, current_game_state.player1.x_coord,
#         current_game_state.player1.y_coord, current_game_state.player1.player_id,
#         current_game_state.player1.is_jumping, current_game_state.player1.is_crouching,
#         current_game_state.player1.is_player_in_move, current_game_state.player1.move_id,
#         current_game_state.player1.player_buttons.up, current_game_state.player1.player_buttons.down,
#         current_game_state.player1.player_buttons.right, current_game_state.player1.player_buttons.left,
#         current_game_state.player1.player_buttons.X, current_game_state.player1.player_buttons.Y,
#         current_game_state.player1.player_buttons.A, current_game_state.player1.player_buttons.B,
#         current_game_state.player1.player_buttons.L, current_game_state.player1.player_buttons.R
#         , current_game_state.player2.health, current_game_state.player2.x_coord,
#         current_game_state.player2.y_coord, current_game_state.player2.player_id,
#         current_game_state.player2.is_jumping, current_game_state.player2.is_crouching,
#         current_game_state.player2.is_player_in_move, current_game_state.player2.move_id,
#         current_game_state.player2.player_buttons.up, current_game_state.player2.player_buttons.down,
#         current_game_state.player2.player_buttons.right, current_game_state.player2.player_buttons.left
#     ]
#
#     with open(csv_file_path, mode='a', newline='') as file:
#         writ = csv.writer(file)
#         if file.tell() == 0:
#             writ.writerow(col)
#         writ.writerow(row_data)
#
#
# def main():
#     if (sys.argv[1] == '1'):
#         client_socket = connect(9999)
#     elif (sys.argv[1] == '2'):
#         client_socket = connect(10000)
#     current_game_state = None
#     # print( current_game_state.is_round_over )
#     bot = Bot()
#     csv_file_path = r'D:\check.csv'
#     while (current_game_state is None) or (not current_game_state.is_round_over):
#         current_game_state = receive(client_socket)
#         bot_command = bot.fight(current_game_state, sys.argv[1])
#         send(client_socket, bot_command)
#         record_to_csv(current_game_state, csv_file_path)
#
#
# if __name__ == '__main__':
#     main()
#
#
#
#
#
#

