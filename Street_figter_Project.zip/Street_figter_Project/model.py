import numpy as np
import pandas as pd
import joblib
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

df = pd.read_csv('LAST.csv', header=None, names=['timer', 'is_round_over', 'fightResult', 'has_round_started', 'health', 'x_coord', 'y_coord', 'player1_id', 'player1_is_jumping', 'player1_is_crouching', 'p1_is_player_in_move', 'p1_move_id', 'player1_buttons_up', 'player1_buttons_down', 'player1_buttons_right', 'player1_buttons_left', 'p1_x', 'p1_y', 'p1_A', 'p1_B', 'p1_L', 'p1_R', 'p2_health', 'p2_x_coord', 'p2_y_coord', 'player2_id', 'player2_is_jumping', 'player2_is_crouching', 'player2_is_player_in_move', 'player2_move_id', 'player2_buttons_up', 'player2_buttons_down', 'player2_buttons_right', 'player2_buttons_left'])

df = df.drop(index=0)

bool_cols = ['is_round_over', 'fightResult', 'has_round_started', 'player1_is_jumping', 'player1_is_crouching', 'p1_is_player_in_move', 'player1_buttons_up', 'player1_buttons_down', 'player1_buttons_right', 'player1_buttons_left', 'p1_x', 'p1_y', 'p1_A', 'p1_B', 'p1_L', 'p1_R', 'player2_is_jumping', 'player2_is_crouching', 'player2_is_player_in_move', 'player2_buttons_up', 'player2_buttons_down', 'player2_buttons_right', 'player2_buttons_left']
df[bool_cols] = df[bool_cols].apply(lambda x: x.map({'NOT_OVER': 0, 'P1': 1, 'P2': 2, 'True': True, 'False': False}))

tar = ['player1_buttons_up', 'player1_buttons_down', 'player1_buttons_right', 'player1_buttons_left', 'p1_x', 'p1_y', 'p1_A', 'p1_B', 'p1_L', 'p1_R']
y = df[tar]
X_train, X_test, y_train, y_test = train_test_split(df, y, test_size=0.2, random_state=42)

X_train = X_train.loc[:, ['is_round_over', 'fightResult', 'has_round_started', 'player1_is_jumping', 'player1_is_crouching', 'p1_is_player_in_move', 'player2_is_jumping', 'player2_is_crouching', 'player2_is_player_in_move', 'player2_buttons_up', 'player2_buttons_down', 'player2_buttons_right', 'player2_buttons_left']]
X_test = X_test.loc[:, ['is_round_over', 'fightResult', 'has_round_started', 'player1_is_jumping', 'player1_is_crouching', 'p1_is_player_in_move', 'player2_is_jumping', 'player2_is_crouching', 'player2_is_player_in_move', 'player2_buttons_up', 'player2_buttons_down', 'player2_buttons_right', 'player2_buttons_left']]

model = DecisionTreeRegressor(random_state=42)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
print(y_pred)

score = model.score(X_test, y_test)
print(f"Model R^2 score: {score:.2f}")

# joblib.dump(model, 'chk_Decision_model.joblib')








# import numpy as np
# import pandas as pd
# import joblib
# from sklearn.tree import DecisionTreeRegressor
# from sklearn.model_selection import train_test_split
# from sklearn.metrics import mean_squared_error
#
# df = pd.read_csv('LAST.csv', header=None, names=['timer', 'is_round_over', 'fightResult', 'has_round_started', 'health', 'x_coord', 'y_coord', 'player1_id', 'player1_is_jumping', 'player1_is_crouching', 'p1_is_player_in_move', 'p1_move_id', 'player1_buttons_up', 'player1_buttons_down', 'player1_buttons_right', 'player1_buttons_left', 'p1_x', 'p1_y', 'p1_A', 'p1_B', 'p1_L', 'p1_R', 'p2_health', 'p2_x_coord', 'p2_y_coord', 'player2_id', 'player2_is_jumping', 'player2_is_crouching', 'player2_is_player_in_move', 'player2_move_id', 'player2_buttons_up', 'player2_buttons_down', 'player2_buttons_right', 'player2_buttons_left'])
#
# df = df.drop(index=0)
#
# bool_cols = ['is_round_over', 'fightResult', 'has_round_started', 'player1_is_jumping', 'player1_is_crouching', 'p1_is_player_in_move', 'player1_buttons_up', 'player1_buttons_down', 'player1_buttons_right', 'player1_buttons_left', 'p1_x', 'p1_y', 'p1_A', 'p1_B', 'p1_L', 'p1_R', 'player2_is_jumping', 'player2_is_crouching', 'player2_is_player_in_move', 'player2_buttons_up', 'player2_buttons_down', 'player2_buttons_right', 'player2_buttons_left']
# df[bool_cols] = df[bool_cols].apply(lambda x: x.map({'NOT_OVER': 0, 'P1': 1, 'P2': 2, 'True': True, 'False': False}))
#
# tar = ['player1_buttons_up', 'player1_buttons_down', 'player1_buttons_right', 'player1_buttons_left', 'p1_x', 'p1_y', 'p1_A', 'p1_B', 'p1_L', 'p1_R']
# y = df[tar]
# X_train, X_test, y_train, y_test = train_test_split(df, y, test_size=0.2, random_state=42)
#
# X_train_features = X_train[['is_round_over', 'fightResult', 'has_round_started', 'player1_is_jumping', 'player1_is_crouching', 'p1_is_player_in_move', 'player2_is_jumping', 'player2_is_crouching', 'player2_is_player_in_move', 'player2_buttons_up', 'player2_buttons_down', 'player2_buttons_right', 'player2_buttons_left']]
# X_test_features = X_test[['is_round_over', 'fightResult', 'has_round_started', 'player1_is_jumping', 'player1_is_crouching', 'p1_is_player_in_move', 'player2_is_jumping', 'player2_is_crouching', 'player2_is_player_in_move', 'player2_buttons_up', 'player2_buttons_down', 'player2_buttons_right', 'player2_buttons_left']]
#
# model = DecisionTreeRegressor()
# model.fit(X_train_features, y_train)
#
# y_pred = model.predict(X_test_features)
# mse = mean_squared_error(y_test, y_pred)
# print(f"Mean Squared Error: {mse}")
